//package kr.co.sist.view;
package kr.co.sist.yj;

import java.awt.Dimension;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

@SuppressWarnings("serial")
public class AdminAccountInstructorAccountView extends JPanel{

	public AdminAccountInstructorAccountView() {
		
		JLabel jlblAdminAccountStudentAccountViewIDTitle = new JLabel("사번");
		JTextField jtfAdminAccountStudentAccountViewIDText = new JTextField(10);
		
		JLabel jlblAdminAccountStudentAccountViewPassTitle = new JLabel("비밀번호");
		JPasswordField jpfAdminAccountStudentAccountViewPassText = new JPasswordField(10);
		
		JLabel jlblAdminAccountStudentAccountViewTelTitle = new JLabel("이름");
		JTextField jtfAdminAccountStudentAccountViewTelText = new JTextField(10);
		
		JLabel jlblAdminAccountStudentAccountViewCardinalTitle = new JLabel("전화번호");
		JTextField jtfAdminAccountStudentAccountViewCardinalText = new JTextField(10);
		
		JPanel jpAdminAccountStudentAccountViewInfoPanel = new JPanel();
		jpAdminAccountStudentAccountViewInfoPanel.add(jlblAdminAccountStudentAccountViewIDTitle);
		jpAdminAccountStudentAccountViewInfoPanel.add(jtfAdminAccountStudentAccountViewIDText);
		jpAdminAccountStudentAccountViewInfoPanel.add(jlblAdminAccountStudentAccountViewPassTitle);
		jpAdminAccountStudentAccountViewInfoPanel.add(jpfAdminAccountStudentAccountViewPassText);
		jpAdminAccountStudentAccountViewInfoPanel.add(jlblAdminAccountStudentAccountViewTelTitle);
		jpAdminAccountStudentAccountViewInfoPanel.add(jtfAdminAccountStudentAccountViewTelText);
		jpAdminAccountStudentAccountViewInfoPanel.add(jlblAdminAccountStudentAccountViewCardinalTitle);
		jpAdminAccountStudentAccountViewInfoPanel.add(jtfAdminAccountStudentAccountViewCardinalText);
		
		//Instructor 계정 테이블 타이틀 생성
		String strAdminAccountViewInstructorAccountTitle[] = { "사번", "이름", "전화번호" };
		String strAdminAccountViewInstructorAccountData[][] = {
				{ "20250001", "곽우신", "010-1234-5678" },
		};
		
		//Table 생성
		DefaultTableModel model =new DefaultTableModel(strAdminAccountViewInstructorAccountData, strAdminAccountViewInstructorAccountTitle);
		JTable jtAdminAccountViewInstructorAccountTable = new JTable(model);
		JScrollPane spAdminAccountViewInstructorAccountScroll = new JScrollPane(jtAdminAccountViewInstructorAccountTable);
		
		//Table 사이즈 설정
		spAdminAccountViewInstructorAccountScroll.setPreferredSize(new Dimension(500,500));
		
		//Table 배치
		add(spAdminAccountViewInstructorAccountScroll);
		
	} //AdminAccountInstructorAccountView
	
} //class