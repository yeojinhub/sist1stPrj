//package kr.co.sist.evt;
package kr.co.sist.yj;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AdminAccountStudentAccountEvt implements ActionListener{

	@Override
	public void actionPerformed(ActionEvent ae) {
		
	} //actionPerformed

} //class