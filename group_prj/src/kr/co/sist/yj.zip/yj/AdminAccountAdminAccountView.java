//package kr.co.sist.view;
package kr.co.sist.yj;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

@SuppressWarnings("serial")
public class AdminAccountAdminAccountView extends JPanel {

	public AdminAccountAdminAccountView() {
		//Student 계정 테이블 타이틀 생성
		String strAdminAccountViewAdminAccountTitle[] = { "사번", "이름", "전화번호" };
		String strAdminAccountViewAdminAccountData[][] = {
				{ "20250001", "정난영", "010-1234-5678" },
		};
		
		//JTable 생성
		JTable jtAdminAccountViewAdminAccountTable = new JTable(strAdminAccountViewAdminAccountData, strAdminAccountViewAdminAccountTitle);
		JScrollPane spAdminAccountViewAdminAccountScroll = new JScrollPane(jtAdminAccountViewAdminAccountTable);
		
		//JTable 배치
		add(spAdminAccountViewAdminAccountScroll);
		
	} //AdminAccountAdminAccountView
	
} //class
