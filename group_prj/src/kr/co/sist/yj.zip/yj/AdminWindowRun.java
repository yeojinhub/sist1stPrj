//package kr.co.sist.run;
package kr.co.sist.yj;

//import kr.co.sist.view.AdminLoginView;

public class AdminWindowRun {

	public static void main(String[] args) {
		new AdminLoginView();
	} //main

} //class
