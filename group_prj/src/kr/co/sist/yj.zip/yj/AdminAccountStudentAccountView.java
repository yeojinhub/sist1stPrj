//package kr.co.sist.view;
package kr.co.sist.yj;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

@SuppressWarnings("serial")
public class AdminAccountStudentAccountView extends JPanel {

    public AdminAccountStudentAccountView() {

        // ---------- 왼쪽 입력 패널 ----------
        JPanel jpAdminAccountStudentAccountViewInfoPanel = new JPanel(new GridBagLayout());
        jpAdminAccountStudentAccountViewInfoPanel.setBorder(new EmptyBorder(15, 15, 15, 15));
        jpAdminAccountStudentAccountViewInfoPanel.setMinimumSize(new Dimension(350, 400));
        jpAdminAccountStudentAccountViewInfoPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 4, 8, 4);
        gbc.anchor = GridBagConstraints.WEST;

        Dimension labelSize = new Dimension(100, 22);
        Dimension fieldSize = new Dimension(200, 22);
//        Dimension buttonSize = new Dimension(50, 22);

        //Component 생성
        //이름 Component 생성
        JLabel jlblAdminAccountStudentAccountNameTitle = new JLabel("이름");
        jlblAdminAccountStudentAccountNameTitle.setPreferredSize(labelSize);
        JTextField jtfAdminAccountStudentAccountNameText = new JTextField();
        jtfAdminAccountStudentAccountNameText.setPreferredSize(fieldSize);
        
        //학번 Component 생성
        JLabel jlblAdminAccountStudentAccountIDTitle = new JLabel("학번");
        jlblAdminAccountStudentAccountIDTitle.setPreferredSize(labelSize);
        JTextField jtfAdminAccountStudentAccountIDText = new JTextField();
        jtfAdminAccountStudentAccountIDText.setPreferredSize(fieldSize);

        //비밀번호 Component 생성
        JLabel jlblAdminAccountStudentAccountPassTitle = new JLabel("비밀번호");
        jlblAdminAccountStudentAccountPassTitle.setPreferredSize(labelSize);
        JPasswordField jpfAdminAccountStudentAccountPassText = new JPasswordField();
        jpfAdminAccountStudentAccountPassText.setPreferredSize(fieldSize);

        //생년월일 Component 생성
        JLabel jlblAdminAccountStudentAccountBirthTitle = new JLabel("생년월일");
        jlblAdminAccountStudentAccountBirthTitle.setPreferredSize(labelSize);
        JTextField jtfAdminAccountStudentAccountBirthText = new JTextField();
        jtfAdminAccountStudentAccountBirthText.setPreferredSize(fieldSize);
        
        //전화번호 Component 생성
        JLabel jlblAdminAccountStudentAccountTelTitle = new JLabel("전화번호");
        jlblAdminAccountStudentAccountTelTitle.setPreferredSize(labelSize);
        JTextField jtfAdminAccountStudentAccountTelText = new JTextField();
        jtfAdminAccountStudentAccountTelText.setPreferredSize(fieldSize);

        //주소 Component 생성
        JLabel jlblAdminAccountStudentAccountAddressTitle = new JLabel("주소");
        jlblAdminAccountStudentAccountAddressTitle.setPreferredSize(labelSize);
        JTextField jtfAdminAccountStudentAccountAddressText = new JTextField();
        jtfAdminAccountStudentAccountAddressText.setPreferredSize(fieldSize);
        
        //과정명 Component 생성
        JLabel jlblAdminAccountStudentAccountCourseNameTitle = new JLabel("과정명");
        jlblAdminAccountStudentAccountCourseNameTitle.setPreferredSize(labelSize);
        String[] strAdminAccountStudentAccountCourseNameTitle = {" AWS와 Docker & Kubernetes", "Flutter Framework"};
        JComboBox<String> jcbAdminAccountStudentAccountCourseNameBox = new JComboBox<String>(strAdminAccountStudentAccountCourseNameTitle);
        jcbAdminAccountStudentAccountCourseNameBox.setPreferredSize(fieldSize);
        
        //강사 Component 생성
        JLabel jlblAdminAccountStudentAccountInstructorNameTitle = new JLabel("담당 강사");
        jlblAdminAccountStudentAccountInstructorNameTitle.setPreferredSize(labelSize);
        JTextField jtfAdminAccountStudentAccountInstructorNameText = new JTextField();
        jtfAdminAccountStudentAccountInstructorNameText.setPreferredSize(fieldSize);
        
        //상태 Component 생성
        JLabel jlblAdminAccountStudentAccountStatusTitle = new JLabel("상태");
        jlblAdminAccountStudentAccountStatusTitle.setPreferredSize(labelSize);
        JTextField jtfAdminAccountStudentAccountStatusText = new JTextField();
        jtfAdminAccountStudentAccountStatusText.setPreferredSize(fieldSize);
        
        //교육기간 Component 생성
        JLabel jlblAdminAccountStudentAccountCourseDateTitle = new JLabel("교육 기간");
        jlblAdminAccountStudentAccountCourseDateTitle.setPreferredSize(labelSize);
        JTextField jtfAdminAccountStudentAccountCourseDateText = new JTextField();
        jtfAdminAccountStudentAccountCourseDateText.setPreferredSize(fieldSize);
        
        //기수 Component 생성
        JLabel jlblAdminAccountStudentAccountCardinalTitle = new JLabel("기수");
        jlblAdminAccountStudentAccountCardinalTitle.setPreferredSize(labelSize);
        JTextField jtfAdminAccountStudentAccountCardinalText = new JTextField();
        jtfAdminAccountStudentAccountCardinalText.setPreferredSize(fieldSize);
        
        //Button 생성
//        JPanel jpAdminAccountStudentAccountButtonPanel = new JPanel();
//        jpAdminAccountStudentAccountButtonPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
//        JButton jbtnAdminAccountStudentAccountCreate = new JButton("생성");
//        JButton jbtnAdminAccountStudentAccountModify = new JButton("수정");
//        JButton jbtnAdminAccountStudentAccountDelete = new JButton("삭제");
//        JButton jbtnAdminAccountStudentAccountClose = new JButton("닫기");
//        jbtnAdminAccountStudentAccountCreate.setPreferredSize(buttonSize);
//        jbtnAdminAccountStudentAccountModify.setPreferredSize(buttonSize);
        
//        jpAdminAccountStudentAccountButtonPanel.add(jbtnAdminAccountStudentAccountCreate);
//        jpAdminAccountStudentAccountButtonPanel.add(jbtnAdminAccountStudentAccountModify);
//        jpAdminAccountStudentAccountButtonPanel.add(jbtnAdminAccountStudentAccountDelete);
//        jpAdminAccountStudentAccountButtonPanel.add(jbtnAdminAccountStudentAccountClose);
        
        
        //Component 배치
        //이름 Component 배치
        gbc.gridx = 0; gbc.gridy = 0;
        jpAdminAccountStudentAccountViewInfoPanel.add(jlblAdminAccountStudentAccountNameTitle, gbc);
        gbc.gridx = 1;
        jpAdminAccountStudentAccountViewInfoPanel.add(jtfAdminAccountStudentAccountNameText, gbc);
        
        //학번 Component 배치
        gbc.gridx = 0; gbc.gridy = 1;
        jpAdminAccountStudentAccountViewInfoPanel.add(jlblAdminAccountStudentAccountIDTitle, gbc);
        gbc.gridx = 1;
        jpAdminAccountStudentAccountViewInfoPanel.add(jtfAdminAccountStudentAccountIDText, gbc);

        //비밀번호 Component 배치
        gbc.gridx = 0; gbc.gridy = 2;
        jpAdminAccountStudentAccountViewInfoPanel.add(jlblAdminAccountStudentAccountPassTitle, gbc);
        gbc.gridx = 1;
        jpAdminAccountStudentAccountViewInfoPanel.add(jpfAdminAccountStudentAccountPassText, gbc);

        //생년월일 Component 배치
        gbc.gridx = 0; gbc.gridy = 3;
        jpAdminAccountStudentAccountViewInfoPanel.add(jlblAdminAccountStudentAccountBirthTitle, gbc);
        gbc.gridx = 1;
        jpAdminAccountStudentAccountViewInfoPanel.add(jtfAdminAccountStudentAccountBirthText, gbc);
        
        //전화번호 Component 배치
        gbc.gridx = 0; gbc.gridy = 4;
        jpAdminAccountStudentAccountViewInfoPanel.add(jlblAdminAccountStudentAccountTelTitle, gbc);
        gbc.gridx = 1;
        jpAdminAccountStudentAccountViewInfoPanel.add(jtfAdminAccountStudentAccountTelText, gbc);

        //주소 Component 배치
        gbc.gridx = 0; gbc.gridy = 5;
        jpAdminAccountStudentAccountViewInfoPanel.add(jlblAdminAccountStudentAccountAddressTitle, gbc);
        gbc.gridx = 1;
        jpAdminAccountStudentAccountViewInfoPanel.add(jtfAdminAccountStudentAccountAddressText, gbc);
        
        //과정명 Component 배치
        gbc.gridx = 0; gbc.gridy = 6;
        jpAdminAccountStudentAccountViewInfoPanel.add(jlblAdminAccountStudentAccountCourseNameTitle, gbc);
        gbc.gridx = 1;
        jpAdminAccountStudentAccountViewInfoPanel.add(jcbAdminAccountStudentAccountCourseNameBox, gbc);
        
        //담당강사 Component 배치
        gbc.gridx = 0; gbc.gridy = 7;
        jpAdminAccountStudentAccountViewInfoPanel.add(jlblAdminAccountStudentAccountInstructorNameTitle, gbc);
        gbc.gridx = 1;
        jpAdminAccountStudentAccountViewInfoPanel.add(jtfAdminAccountStudentAccountInstructorNameText, gbc);
        
        //교육기간 Component 배치
        gbc.gridx = 0; gbc.gridy = 8;
        jpAdminAccountStudentAccountViewInfoPanel.add(jlblAdminAccountStudentAccountCourseDateTitle, gbc);
        gbc.gridx = 1;
        jpAdminAccountStudentAccountViewInfoPanel.add(jtfAdminAccountStudentAccountCourseDateText, gbc);
        
        //상태 Component 배치
        gbc.gridx = 0; gbc.gridy = 9;
        jpAdminAccountStudentAccountViewInfoPanel.add(jlblAdminAccountStudentAccountStatusTitle, gbc);
        gbc.gridx = 1;
        jpAdminAccountStudentAccountViewInfoPanel.add(jtfAdminAccountStudentAccountStatusText, gbc);
        
        //기수 Component 배치
        gbc.gridx = 0; gbc.gridy = 10;
        jpAdminAccountStudentAccountViewInfoPanel.add(jlblAdminAccountStudentAccountCardinalTitle, gbc);
        gbc.gridx = 1;
        jpAdminAccountStudentAccountViewInfoPanel.add(jtfAdminAccountStudentAccountCardinalText, gbc);
        
        //버튼 Component 배치
//        gbc.gridx = 0; gbc.gridy = 11;
//        gbc.gridwidth = 2;  // 두 열을 합쳐서 버튼들을 가운데로 배치
//        jpAdminAccountStudentAccountViewInfoPanel.add(jpAdminAccountStudentAccountButtonPanel, gbc);

        // ---------- 테이블 ----------
        String[] strAdminAccountStudentAccountViewTableTitle = {
            "학번", "이름", "전화번호", "기수", "교육과정", "교육기간", "진행상태"
        };

        String[][] strAdminAccountStudentAccountViewTableData = {
            { "20250001", "강태일", "010-1234-5678", "25-3", "JAVA과정", "2025-01-13~2025-07-25", "진행중" },
            { "20250002", "김민경", "010-1111-1111", "25-3", "JAVA과정", "2025-01-13~2025-07-25", "진행중" },
            { "20250003", "이여진", "010-8241-8701", "25-3", "JAVA과정", "2025-01-13~2025-07-25", "진행중" },
            { "20250004", "이재준", "010-0000-0000", "25-3", "JAVA과정", "2025-01-13~2025-07-25", "중도하차" },
        };

        DefaultTableModel dftmStudentTableModel = new DefaultTableModel(strAdminAccountStudentAccountViewTableData, strAdminAccountStudentAccountViewTableTitle);
        JTable jtAdminAccountStudentAccountViewTable = new JTable(dftmStudentTableModel);

        // ✅ 자동 열 너비 조절 (테이블 크기에 맞춤)
//        jtAdminAccountViewStudentAccountTable.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

        JScrollPane spAdminAccountStudentAccountViewScroll = new JScrollPane(jtAdminAccountStudentAccountViewTable);
        spAdminAccountStudentAccountViewScroll.setPreferredSize(new Dimension(1000,500));


        JPanel jpAdminAccountStudentAccountViewTablePanel = new JPanel(new BorderLayout());
        jpAdminAccountStudentAccountViewTablePanel.add(spAdminAccountStudentAccountViewScroll, BorderLayout.CENTER);

        // ---------- 좌우 구성 ----------
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, jpAdminAccountStudentAccountViewInfoPanel, jpAdminAccountStudentAccountViewTablePanel);
        splitPane.setDividerLocation(250);
        splitPane.setResizeWeight(0);
        splitPane.setOneTouchExpandable(true);
        
        setLayout(new BorderLayout());
        add(splitPane, BorderLayout.CENTER);
    }
}