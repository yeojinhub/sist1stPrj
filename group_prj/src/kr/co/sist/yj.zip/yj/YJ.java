package kr.co.sist.yj;

public class YJ {

	public static void main(String[] args) {
		System.out.println("난 YJ");
		System.out.println("한번더 commit");
	} //main

} //class
